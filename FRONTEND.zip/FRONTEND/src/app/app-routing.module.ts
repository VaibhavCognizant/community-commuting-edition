import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookRideComponent } from './components/book-ride/book-ride.component';
import { BookedRidesComponent } from './components/booked-rides/booked-rides.component';
import { LoginComponent } from './components/login/login.component';
import { PasswordForUserComponent } from './components/password-for-user/password-for-user.component';
import { RegisterComponent } from './components/register/register.component';
import { RidesComponent } from './components/rides/rides.component';
import { UpdateAndUnregisterComponent } from './components/update-and-unregister/update-and-unregister.component';
import { AuthenticationService } from './services/auth-service/authentication.service';

const routes: Routes = [
  {path: 'registerRideSeeker',component: RegisterComponent},
  {path: 'updateRideSeeker',component: UpdateAndUnregisterComponent,canActivate : [AuthenticationService]},
  {path: 'viewRides',component: RidesComponent,canActivate : [AuthenticationService]},
  {path: 'bookRide' ,component: BookRideComponent,canActivate : [AuthenticationService]},
  {path: 'bookedRides',component: BookedRidesComponent,canActivate : [AuthenticationService]},
  {path: 'passwordSetting', component: PasswordForUserComponent},
  {path: 'login',component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
