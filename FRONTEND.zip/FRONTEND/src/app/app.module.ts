import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './components/register/register.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {FormsModule,ReactiveFormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http';
import { UpdateAndUnregisterComponent } from './components/update-and-unregister/update-and-unregister.component';
import { RidesComponent } from './components/rides/rides.component';
import { BookRideComponent } from './components/book-ride/book-ride.component';
import { BookedRidesComponent } from './components/booked-rides/booked-rides.component';
import { PasswordForUserComponent } from './components/password-for-user/password-for-user.component';
import { LoginComponent } from './components/login/login.component'


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    NavigationComponent,
    UpdateAndUnregisterComponent,
    RidesComponent,
    BookRideComponent,
    BookedRidesComponent,
    PasswordForUserComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
