import { Component, OnInit } from '@angular/core';
import { min } from 'rxjs';
import { BookAndCancel } from 'src/app/datatransferclasses/book-and-cancel';
import { Ride } from 'src/app/datatransferclasses/ride';
import { RideServiceService } from 'src/app/services/bookandcancelride-services/ride-service.service';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { UserService } from 'src/app/services/user-service/user.service';
  
@Component({
  selector: 'app-book-ride',
  templateUrl: './book-ride.component.html',
  styleUrls: ['./book-ride.component.css']
})
export class BookRideComponent implements OnInit {

  min=1;
  max=1000;
  bookRide : BookAndCancel = new BookAndCancel();
  ride : Ride = new Ride();
  bookedRides !: BookAndCancel[];
  bookrideforsession:any
  bookridetoadd:any
  bookarray:any[]=[];
  ridesInfo !: Ride[];


  constructor(private rideService : RideServiceService,private router : Router,private userService : UserService) { 
  }

  bookRideForm = new FormGroup({
    requiredNoOfSeats : new FormControl('',[Validators.required,Validators.pattern('[1-9]+$')])
  })

  ngOnInit(): void {
    
  }

  //for getting the ride details
  getRideDetails(){
    this.ride = this.rideService.getRideValues();
  }

  //for setting the required booking details
  setBookingDetails(){
    
    this.bookRide.filledSeats = this.ride.filledSeats;
    this.bookRide.rideStatus = this.ride.rideStatus;
    this.bookRide.totalNoOfSeats = this.ride.totalNoOfSeats;
    this.bookRide.tripId = this.ride.tripId;
    this.bookRide.seekerId = String(localStorage.getItem('userId'));
    this.bookRide.bookingId = ""+Math.floor(Math.random()*(this.max-this.min+1))+this.min+this.bookRide.seekerId;
  }

  onSubmit(){
    // console.log("in submit");
    this.getRideDetails();
    this.setBookingDetails();
    console.log(this.bookRide)
    this.rideService.bookRide(this.bookRide).subscribe(
      data=>{
        console.log(data);
        alert("Booked Ride")
        setTimeout(() => {
          this.router.navigate(['viewRides']);
        }, 3000);
      },
      error=>{
        console.log(error);
        alert(error.error[0]);
      }
    )
    // console.log(this.ride);
    // console.log(this.bookRide);
  }


  get requiredNoOfSeats(){
    return this.bookRideForm.get('requiredNoOfSeats')
  }

 

}


