import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { BookAndCancel } from 'src/app/datatransferclasses/book-and-cancel';
import { RideServiceService } from 'src/app/services/bookandcancelride-services/ride-service.service';

@Component({
  selector: 'app-booked-rides',
  templateUrl: './booked-rides.component.html',
  styleUrls: ['./booked-rides.component.css']
})
export class BookedRidesComponent implements OnInit {

  submitted : Boolean = false;
  idForm = new FormGroup({
    seekerId : new FormControl('',[Validators.required])
  });
  bookedRide : BookAndCancel = new BookAndCancel();
  bookedRides !: BookAndCancel[];

  constructor(private bookedRideService : RideServiceService,private router : Router) { }

  ngOnInit(): void {
    this.bookedRide.seekerId = String(localStorage.getItem('userId'))
   
    this.bookedRideService.alreadyBookedRides(this.bookedRide).subscribe(
      data=>{
        console.log(data);
        this.bookedRides = data;
        this.submitted = true;
      },
      error=>{
        console.log(error);
      }
    )
  }

  onIdSubmit(){
    
  }
  


  onClick(ride : BookAndCancel){
    
    let rideToBeCancelled = localStorage.getItem(`${ride.tripId}`);
    console.log("local value : ",rideToBeCancelled);
    
    // if(rideToBeCancelled){
    //   let filledSeats = rideToBeCancelled.
    // }


    this.bookedRideService.cancelRide(ride).subscribe(
      data=>{
        console.log(data);
        alert('Ride Cancelled'); 
      },
      error=>{
        console.log(error);
      }
    )
  }

  get seekerId(){
    return this.idForm.get('seekerId');
  }

}
