import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/datatransferclasses/user';
import { UserService } from 'src/app/services/user-service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm = new FormGroup({
    password : new FormControl('',[Validators.required,Validators.minLength(8)]),
    userId : new FormControl('',[Validators.required])
  })
  user : User = new User();
  constructor(private userService : UserService,private router : Router) { }

  ngOnInit(): void {
  }


  get password(){
    return this.loginForm.get('password');
  }
  get userId(){
    return this.loginForm.get('userId');
  }

  onSubmit(){
    this.userService.login(this.user).subscribe(
      data=>{
        console.log(data);
        this.userService.setUserId(data.userId);
        localStorage.setItem('userId',data.userId.toString());
        localStorage.setItem('role',data.role.toString());
        this.router.navigate(['viewRides'])
      },
      error=>{
        console.log(error);
      }
    )
  }
}
