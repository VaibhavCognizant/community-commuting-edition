import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordForUserComponent } from './password-for-user.component';

describe('PasswordForUserComponent', () => {
  let component: PasswordForUserComponent;
  let fixture: ComponentFixture<PasswordForUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PasswordForUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PasswordForUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
