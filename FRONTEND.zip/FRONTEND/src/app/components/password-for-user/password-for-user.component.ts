import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/datatransferclasses/user';
import { UserService } from 'src/app/services/user-service/user.service';

@Component({
  selector: 'app-password-for-user',
  templateUrl: './password-for-user.component.html',
  styleUrls: ['./password-for-user.component.css']
})
export class PasswordForUserComponent implements OnInit {


  user : User = new User();
  submit : Boolean = false;

  passwordForm = new FormGroup({
    password : new FormControl('',[Validators.required,Validators.minLength(8)])
  })


  constructor(private userService :UserService,private router : Router) { }

  ngOnInit(): void {
  }

  get password(){
    return this.passwordForm.get('password');
  }

  onSubmit(){

    this.user.userId = this.userService.getUserId();
    this.user.role="User";
    
    this.userService.addUserCredentials(this.user).subscribe(
      data=>{
        console.log(data);
        this.userService.setUserId("");
        setTimeout(() => {
          this.router.navigate(['login']);
        },5000);
      },
      error=>{
        console.log(error);
      }
    )
  }

}
