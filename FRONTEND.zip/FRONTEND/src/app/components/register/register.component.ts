import { Component, OnInit } from '@angular/core';
import { Rideseeker } from '../../datatransferclasses/rideseeker';
import { RideseekerServiceService } from '../../services/rideseeker-services/rideseeker-service.service';
import {FormGroup,FormControl,Validators} from '@angular/forms'
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user-service/user.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  hide : Boolean =false;
  seekerDetail !: String;


  registerForm = new FormGroup(
    {
      firstName : new FormControl('',[Validators.required]),
      lastName : new FormControl('',[Validators.required,Validators.minLength(3)]),
      emailId : new FormControl('',[Validators.required,Validators.email,Validators.pattern('^[a-zA-Z0-9._%+-]+@cognizant\.com$')]),
      adharCard : new FormControl('',[Validators.required,Validators.pattern('[0-9]+$'),Validators.minLength(12),Validators.maxLength(12)]),
      phone : new FormControl('',[Validators.required,Validators.pattern('[0-9]+$'),Validators.minLength(10),Validators.maxLength(10)]),
      address : new FormControl('',[Validators.required]),
      yearOfBirth : new FormControl('',[Validators.required,Validators.pattern('[0-9]+$'),Validators.minLength(4),Validators.maxLength(4)])

    }
  );



  rideSeeker : Rideseeker = new Rideseeker();
  submitted = false;

  constructor(private rideSeekerService : RideseekerServiceService,private router : Router,private userService :UserService) { }

  ngOnInit(): void {
  }

  save(){
    this.rideSeekerService.registerRideSeeker(this.rideSeeker).subscribe(data => {
      console.log(data);
      this.seekerDetail = "Seeker Id is "+data[0];
      this.userService.setUserId(data[0]);
      setTimeout(() => {
        this.router.navigate(['passwordSetting']);
      }, 5000);
      
    },error => {
      console.log(error.error);
      this.seekerDetail = error.error[0];
    });
    this.rideSeeker = new Rideseeker();
    this.hide = true;
    // console.log("In save")
  }

  onSubmit(){
    // console.log("In submit")
    this.submitted = true;
    this.save();
  }

  get firstName(){
    return this.registerForm.get('firstName');
  }

  get lastName(){
    return this.registerForm.get('lastName');
  }

  get emailId(){
    return this.registerForm.get('emailId');
  }

  get address(){
    return this.registerForm.get('address');
  }

  get adharCard(){
    return this.registerForm.get('adharCard');
  }

  get phone(){
    return this.registerForm.get('phone');
  }

  get yearOfBirth(){
    return this.registerForm.get('yearOfBirth');
  }

}
