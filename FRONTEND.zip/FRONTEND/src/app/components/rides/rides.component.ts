import { Component, OnInit, Output } from '@angular/core';
import { Ride } from '../../datatransferclasses/ride';
import { RideServiceService } from '../../services/bookandcancelride-services/ride-service.service';
import { Router } from '@angular/router';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-rides',
  templateUrl: './rides.component.html',
  styleUrls: ['./rides.component.css']
})
export class RidesComponent implements OnInit {

  rides!: Ride[];
  ridesInfo !: Ride[];
  ride : Ride = new Ride();
  

  searchRide = new FormGroup({
    
  })

  constructor(private rideService : RideServiceService,private router : Router) { }




  ngOnInit(): void {
      this.rideService.getAllRides().subscribe(
        data => {
          this.rides = data;
          localStorage.setItem('trips',JSON.stringify(this.rides));


          let storedtrip = localStorage.getItem('trips');
          if(storedtrip){
            this.ridesInfo=JSON.parse(storedtrip);
          }
          console.log("Rides->",this.rides);
          console.log("RideInfo->",this.ridesInfo);
        },
        error => {
          console.log(error)
        }
      )
  }

  onBook(ride : Ride){
    console.log(ride)
    localStorage.setItem(`${ride.tripId}`,JSON.stringify(ride));
    this.rideService.setRideValues(ride);
    this.router.navigate(['bookRide']);
  }

  // onCancel(ride : Ride){
  //   this.rideService.setRideValues(ride);
  //   this.router.navigate(['cancelRide']);
  // }

}
