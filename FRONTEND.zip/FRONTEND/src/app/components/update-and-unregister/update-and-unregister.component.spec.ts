import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAndUnregisterComponent } from './update-and-unregister.component';

describe('UpdateAndUnregisterComponent', () => {
  let component: UpdateAndUnregisterComponent;
  let fixture: ComponentFixture<UpdateAndUnregisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateAndUnregisterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateAndUnregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
