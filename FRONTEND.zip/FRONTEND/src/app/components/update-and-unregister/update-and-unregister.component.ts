import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Rideseeker } from '../../datatransferclasses/rideseeker';
import { RideseekerServiceService } from '../../services/rideseeker-services/rideseeker-service.service';



@Component({
  selector: 'app-update-and-unregister',
  templateUrl: './update-and-unregister.component.html',
  styleUrls: ['./update-and-unregister.component.css']
})
export class UpdateAndUnregisterComponent implements OnInit {

  rideSeeker : Rideseeker = new Rideseeker();
  responseData : Boolean = false;
  submitted : Boolean = false;
  responseError : Boolean = false;
  updateDataResponse !: String; 


  idForm = new FormGroup(
    {
      rsId : new FormControl('',[Validators.required])
    }
  );

  updateForm = new FormGroup(
    {
      firstName : new FormControl('',[Validators.required]),
      lastName : new FormControl('',[Validators.required,Validators.minLength(3)]),
      emailId : new FormControl('',[Validators.required,Validators.email,Validators.pattern('^[a-zA-Z0-9._%+-]+@cognizant\.com$')]),
      phone : new FormControl('',[Validators.required,Validators.pattern('[0-9]+$'),Validators.minLength(10),Validators.maxLength(10)]),
      address : new FormControl('',[Validators.required]),
    }
  );

  constructor(private riseSeekerService : RideseekerServiceService,private router :Router) { }

  ngOnInit(): void {
    this.rideSeeker.rsId = String(localStorage.getItem('userId'));
  
    this.riseSeekerService.getRideSeekerById(this.rideSeeker).subscribe(
      data => {
        this.rideSeeker = data;
        this.responseData = true;
        if(this.rideSeeker.status == 'Un-registered'){
          localStorage.setItem('role',"");
          localStorage.setItem('UserId',"");
          this.router.navigate(['login']);
          
        }
          
      },
      error => {
        this.responseError = true;
      }
    );

  }

 

  onUpdateFormSubmit(){
    console.log(this.rideSeeker)
    this.riseSeekerService.updateRideSeeker(this.rideSeeker).subscribe(
      data =>{
        console.log(data);        
        this.updateDataResponse = "Data Updated";
        alert("Data Updated");
        if(this.rideSeeker.status === "Un-registered"){
          localStorage.setItem('userId',"");
          localStorage.setItem('role',"");
          this.router.navigate(['login']);

        }
        else
          this.router.navigate(['viewRides'])
      },
      error =>{
        console.log(error);
        this.updateDataResponse = "Data not updated";
        alert("Data Not Updated");
      }
    )
    this.submitted = false;
    
    
  }
  

  updateStatus(event : Event){
    const target = event.target as HTMLInputElement;
    this.rideSeeker.status = target.value;
  }

  get rsId(){
    return this.idForm.get('rsId');
  }
  get firstName(){
    return this.updateForm.get('firstName');
  }

  get lastName(){
    return this.updateForm.get('lastName');
  }

  get emailId(){
    return this.updateForm.get('emailId');
  }

  get address(){
    return this.updateForm.get('address');
  }

  get adharCard(){
    return this.updateForm.get('adharCard');
  }

  get phone(){
    return this.updateForm.get('phone');
  }

  get yearOfBirth(){
    return this.updateForm.get('yearOfBirth');
  }

}
