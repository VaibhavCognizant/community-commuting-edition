import { BookAndCancel } from './book-and-cancel';

describe('BookAndCancel', () => {
  it('should create an instance', () => {
    expect(new BookAndCancel()).toBeTruthy();
  });
});
