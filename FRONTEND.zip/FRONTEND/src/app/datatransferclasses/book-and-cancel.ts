export class BookAndCancel {
    bookingId !: String;
    tripId !: String;
    totalNoOfSeats !: number;
    seekerId !: String;
    filledSeats !: number;
    status !: String;
    rideStatus !: String;
    requiredNoOfSeats !:number;
}
