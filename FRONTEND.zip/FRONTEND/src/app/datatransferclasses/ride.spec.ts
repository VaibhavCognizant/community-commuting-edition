import { Ride } from './ride';

describe('Ride', () => {
  it('should create an instance', () => {
    expect(new Ride()).toBeTruthy();
  });
});
