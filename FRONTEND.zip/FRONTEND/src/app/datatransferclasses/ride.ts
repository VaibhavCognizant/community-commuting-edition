export class Ride {
    tripId !: string;
    totalNoOfSeats !: number;
    filledSeats !: number;
    rideStatus !: string;
    source !: string;
    destination !: string;
    date !: Date;

}
