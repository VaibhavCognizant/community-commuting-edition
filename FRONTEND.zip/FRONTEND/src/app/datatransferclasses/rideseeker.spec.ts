import { Rideseeker } from './rideseeker';

describe('Rideseeker', () => {
  it('should create an instance', () => {
    expect(new Rideseeker()).toBeTruthy();
  });
});
