export class Rideseeker {
    firstName!: string;
    lastName!:string;
    adharCard!: string;
    emailId!:string;
    phone!:string;
    address!:string;
    yearOfBirth!:string;
    status!:string;
    rsId!:string;
}
