export class User {
    userId !: String;
	password !: String;
	role !:String;
}
