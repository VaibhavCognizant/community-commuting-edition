import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService implements CanActivate{

  constructor(private router : Router) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (localStorage.getItem('role')=="User")
      return true;

    this.router.navigate(['login']);
    return false;

  }

  isUserLoggedIn(){
    let userId = localStorage.getItem('userId');
    let role = localStorage.getItem("role");

    return (userId == null && role == null);
  }

}
