import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Ride } from 'src/app/datatransferclasses/ride';
import { BookAndCancel } from 'src/app/datatransferclasses/book-and-cancel';

const httpOption = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class RideServiceService {

  private url = 'http://localhost:8084/api/rideSeeker';
  ride : Ride = new Ride();

  constructor(private http : HttpClient) { }

  public getAllRides(){
    return this.http.get<Ride[]>(this.url+'/getRides');
  }

  public bookRide(bookRide : BookAndCancel){
   
    return this.http.post<BookAndCancel>(this.url+"/bookRide",bookRide);
  }

  public cancelRide(cancelRide : BookAndCancel){
    console.log(cancelRide.seekerId);
    return this.http.put<BookAndCancel>(this.url+"/"+cancelRide.seekerId+"/updateRide",cancelRide);
  }

  public alreadyBookedRides(bookedRides : BookAndCancel){
    
    return this.http.get<BookAndCancel[]>(this.url+"/"+bookedRides.seekerId+"/getbookedRides");
  }

  public setRideValues(ride : Ride){
    // console.log("In set ride value")
    this.ride = ride;
    // console.log("This Ride"+this.ride.tripId)
  }

  public getRideValues(){
    return this.ride;
  }
}
