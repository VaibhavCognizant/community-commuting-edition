import { TestBed } from '@angular/core/testing';

import { RideseekerServiceService } from './rideseeker-service.service';

describe('RideseekerServiceService', () => {
  let service: RideseekerServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RideseekerServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
