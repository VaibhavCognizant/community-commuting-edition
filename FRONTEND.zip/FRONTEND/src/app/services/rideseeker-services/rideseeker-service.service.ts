import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Rideseeker } from 'src/app/datatransferclasses/rideseeker';

const httpOption = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class RideseekerServiceService {

  private url = 'http://localhost:8084/api/rideSeeker';
  constructor(private http:HttpClient) { }

  public registerRideSeeker(rideseeker: Rideseeker){
    return this.http.post<String[]>(this.url+"/new",rideseeker);
  }

  public getRideSeekerById(rideseeker : Rideseeker){
    return this.http.get<Rideseeker>(this.url+"/"+rideseeker.rsId+"/getDetails")
  }

  public updateRideSeeker(rideSeeker : Rideseeker ){
    return this.http.put<String>(this.url+"/"+rideSeeker.rsId+"/update",rideSeeker);
  }
}
