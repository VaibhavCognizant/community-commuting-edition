import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from 'src/app/datatransferclasses/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userId !: String;
  private url = 'http://localhost:8084/api/rideSeeker';

  constructor(private http : HttpClient) { }

  setUserId(userId : String){
    this.userId = userId;
  }

  getUserId(){
    return this.userId;
  }

  addUserCredentials(user : User){
    return this.http.post<User>(this.url+"/"+user.userId+"/newUser",user);
  }

  login(user : User){
    return this.http.post<User>(this.url+"/login",user);
  }
}
