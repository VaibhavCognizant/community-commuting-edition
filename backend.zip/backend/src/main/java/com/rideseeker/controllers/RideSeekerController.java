package com.rideseeker.controllers;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rideseeker.customexception.IdNotPresent;
import com.rideseeker.models.BookRideDTO;
import com.rideseeker.models.ResponseDTO;
import com.rideseeker.models.RideDTO;
import com.rideseeker.models.RideSeekerDTO;
import com.rideseeker.models.UserDTO;
import com.rideseeker.services.BookAndCancelRideService;
import com.rideseeker.services.RideSeekerService;
import com.rideseeker.services.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/rideSeeker")
@Validated
@CrossOrigin
 public class RideSeekerController {
	
	@Autowired
	private RideSeekerService rideSeekerService;
	
	@Autowired
	private BookAndCancelRideService bookAndCancel;
	
	@Autowired
	private UserService userService;
	

	
	@PostMapping("/new") 
	public ResponseEntity<?> registerRideSeeker(@Valid @RequestBody RideSeekerDTO rideSeekerDTO){
		List<String> response = rideSeekerService.registerRideSeeker(rideSeekerDTO);

		if(!response.isEmpty()) {
			if(response.get(1).equals("success"))
				return new ResponseEntity<>(response,HttpStatus.CREATED);
			else
				return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
	}
	

	
	@PutMapping("/{rsId}/update")
	public ResponseEntity<?> unregisterOrUpdateRideSeeker(@PathVariable String rsId,@Valid @RequestBody RideSeekerDTO rideSeekerDTO){
		String response = rideSeekerService.unRegisterRideSeekerOrUpdate(rsId, rideSeekerDTO);
		if(response.equals("success")) {
			ResponseDTO obj= new ResponseDTO();
			obj.setStatus(response);
			return new ResponseEntity<>(obj,HttpStatus.OK);
		}
		else
			return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
	}
	
	
	@GetMapping("/{rsId}/getDetails")
	public ResponseEntity<?> getRideSeekerDetails(@PathVariable String rsId) throws IdNotPresent{
		RideSeekerDTO rideSeekerDTO = rideSeekerService.getRideSeekerBasedOnId(rsId);	
		return new ResponseEntity<>(rideSeekerDTO,HttpStatus.OK);
		
	}
	
	@GetMapping("/getRides")
	public ResponseEntity<?> getExistingRides(){
		List<RideDTO> list= bookAndCancel.getExistingRides();	
		return new ResponseEntity<>(list , HttpStatus.OK);
	}
	
	
	@PostMapping("/bookRide")
	public ResponseEntity<?> bookRide(@RequestBody BookRideDTO bookride){
		List<String> response = bookAndCancel.bookRide(bookride);
		if(response.get(1).equals("success"))
			return new ResponseEntity<>(response,HttpStatus.CREATED);
		else
			return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
	}
	

	@PutMapping("/{seekerId}/updateRide")
	public ResponseEntity<?> cancelRide(@RequestBody BookRideDTO bookride){
		List<String> response = bookAndCancel.cancelRide(bookride);
		if(response.get(0).equals("success"))
			return new ResponseEntity<>(response,HttpStatus.OK);
		else
			return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
	}
	
	@GetMapping("/{seekerId}/getbookedRides")
	public ResponseEntity<?> bookedRideForUser(@PathVariable String seekerId){
		System.out.println(seekerId);
		List<BookRideDTO> bookedrides = bookAndCancel.bookedRides(seekerId);
		if(bookedrides.isEmpty())
			return new ResponseEntity<>(bookedrides,HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<>(bookedrides,HttpStatus.OK);
	}
	
	
	@PostMapping("/{seekerId}/newUser")
	public ResponseEntity<?> addNewUser(@RequestBody UserDTO user){
		UserDTO userAdded = userService.addNewUser(user);
		if(userAdded.getUserId().isEmpty()) {
			return new ResponseEntity<>(userAdded,HttpStatus.BAD_REQUEST);
		}
		else {
			return new ResponseEntity<>(userAdded,HttpStatus.OK);
		}
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody UserDTO userCredentials){
		UserDTO user = userService.logIn(userCredentials);
		if(user.getUserId().isEmpty()) {
			return new ResponseEntity<>(user,HttpStatus.BAD_REQUEST);
		}
		else {
			return new ResponseEntity<>(user,HttpStatus.OK);
		}
	}
}
