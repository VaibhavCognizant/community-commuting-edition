package com.rideseeker.customexception;

public class IdNotPresent extends Exception{
	public IdNotPresent() {
		super("Id does not exists");
	}
}
