package com.rideseeker.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "booking")
@Data
public class Booking {
	
	@Id
	@Column(name = "bookingid")
	private String bookingId;
	
	@Column(name = "tripid")
	private String tripId;
	
	
	@Column(name = "seekerid")
	private String seekerId;
	
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "ridestatus")
	private String rideStatus;
	
	@Column(name = "requirednoofseats")
	private int requiredNoOfSeats;
}
