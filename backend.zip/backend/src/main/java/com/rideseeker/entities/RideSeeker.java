package com.rideseeker.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


@Data
@Entity
@Table(name="rideseeker")
public class RideSeeker {
	
	@Id
	@Column(name="rsid")
	private String rsId;
	
	@Column(name="adharcard")
	private long adharCard;
	
	@Column(name="emailid")
	private String emailId;
	
	@Column(name="phone")
	private long phone;
	
	@Column(name="firstname")
	private String firstName;
	
	@Column(name="lastname")
	private String lastName;
	
	@Column(name="address")
	private String address;
	
	@Column(name="status")
	private String status;

	
	
	
	
}
