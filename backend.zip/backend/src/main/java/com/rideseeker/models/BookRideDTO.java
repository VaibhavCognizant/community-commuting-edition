package com.rideseeker.models;

import lombok.Data;


@Data
public class BookRideDTO {

	private String bookingId;
	
	private String tripId;
	
	private int totalNoOfSeats;
	
	private String seekerId;
	
	private int filledSeats;
	
	private String status;
	
	private String rideStatus;
	
	private int requiredNoOfSeats;


}
