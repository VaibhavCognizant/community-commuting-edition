package com.rideseeker.models;

import lombok.Data;

@Data
public class ResponseDTO {
	private String status;

}
