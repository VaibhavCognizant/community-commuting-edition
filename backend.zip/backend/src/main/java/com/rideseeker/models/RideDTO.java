package com.rideseeker.models;

import java.time.LocalDate;

import lombok.Data;

@Data
public class RideDTO {
	
	private String tripId;
	private int totalNoOfSeats;
	private int filledSeats;
	private String rideStatus;
	private String source;
	private String destination;
	private LocalDate date;
	
	public RideDTO(String tripId, int totalNoOfSeats, int filledSeats, String rideStatus, String source,
			String destination, LocalDate date) {
		super();
		this.tripId = tripId;
		this.totalNoOfSeats = totalNoOfSeats;
		this.filledSeats = filledSeats;
		this.rideStatus = rideStatus;
		this.source = source;
		this.destination = destination;
		this.date = date;
	}
}
