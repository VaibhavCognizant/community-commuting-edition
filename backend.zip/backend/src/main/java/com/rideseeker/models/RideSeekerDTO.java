package com.rideseeker.models;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;


@Data
public class RideSeekerDTO {
	


	private String rsId;
	
	@NotNull(message = "Adhar Card is required")
	@Digits(integer=12, fraction = 0 ,message="Adharcard should contain numbers")
	@Size(min=12 , max=12 , message="AdharCard must be 12 digits long")
	private String adharCard;	
	
	@NotNull(message = "Email id is required")
	@Email(message = "Invalid email format")
	@Pattern(regexp = ".*@cognizant.com$", message="Email address must end with @cognizant.com")
	private String emailId;
	
	@NotNull(message = "Phone number is required")
	@Digits(fraction = 0, integer = 10 , message="Phone number must be in digits")
	@Size(min=10 , max=10 , message="Phone no must be 10 digits long")
	private String phone;
	
	@NotBlank(message="First name is required")
	@Pattern(regexp = "[a-zA-Z]+" ,message="First name should contain alphabets")
	private String firstName;
	
	@NotBlank(message = "Last name is required")
	@Pattern(regexp="[a-zA-Z]+", message="Last name should contain alphabets")
	@Size(min=3 , message="Last name must be 3 characters long")
	private String lastName;

	@NotNull(message = "Address is required")
	private String address;
	
	@Pattern(regexp="^(Registered|Un-registered)$",message="Updation status is incorrect")
	private String status;
	
//	@NotNull(message="Year of birth is required")
	@Pattern(regexp="[0-9]+" , message="Year of Birth must be in digits")
	private String yearOfBirth;
	
	
	
}
