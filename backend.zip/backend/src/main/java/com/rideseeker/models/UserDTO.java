package com.rideseeker.models;


import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UserDTO {
	
	@NotNull(message = "User Id is required")
	String userId;
	
	@NotNull(message = "Password is required")
	String password;
	
	@NotNull(message = "Role is required")
	String role;
}
