package com.rideseeker.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rideseeker.entities.Booking;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, String>{
	List<Booking> findBySeekerId(String seekerId);
	void deleteBySeekerId(String seekerId);
}
