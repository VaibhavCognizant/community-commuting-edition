package com.rideseeker.repository;



import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rideseeker.entities.RideSeeker;


@Repository
public interface RideSeekerRepository extends JpaRepository<RideSeeker,String>{
	Optional<RideSeeker> findByAdharCard(long adharCard);
}
