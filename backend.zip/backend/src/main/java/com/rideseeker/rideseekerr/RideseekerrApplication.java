package com.rideseeker.rideseekerr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
 
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.rideseeker.*")
@EntityScan(value = "com.rideseeker.Entities")
@EnableJpaRepositories(basePackages = "com.rideseeker.repository")
public class RideseekerrApplication {

	public static void main(String[] args) {
		SpringApplication.run(RideseekerrApplication.class, args);
		
	}

}
