package com.rideseeker.services;

import java.util.List;


import com.rideseeker.models.BookRideDTO;
import com.rideseeker.models.RideDTO;

public interface BookAndCancelRideService {
	public List<String> bookRide(BookRideDTO bookRideDTO);
	public List<String> cancelRide(BookRideDTO bookRideDTO);
	public List<RideDTO> getExistingRides();
	public List<BookRideDTO> bookedRides(String seekerId);
}
