package com.rideseeker.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rideseeker.entities.Booking;
import com.rideseeker.entities.RideSeeker;
import com.rideseeker.models.BookRideDTO;
import com.rideseeker.models.RideDTO;
import com.rideseeker.repository.BookingRepository;
import com.rideseeker.repository.RideSeekerRepository;

@Service
public class BookAndCancelRideServiceImpl implements BookAndCancelRideService {

	@Autowired
	private RideSeekerRepository rideSeekerRepository;

	@Autowired
	private BookingRepository bookingRepository;
	
	
	List<RideDTO> list= new  ArrayList<RideDTO>(List.of(
			new RideDTO("Trip01",20,14,"Planed","Delhi","Amritsar",LocalDate.parse("2023-06-12")),
			new RideDTO("Trip02",30,16,"Started","Delhi","Chandigarh",LocalDate.parse("2023-06-16")),
			new RideDTO("Trip03",15,4,"Planed","Chandigarh","Amritsar",LocalDate.parse("2023-06-14")),
			new RideDTO("Trip04",32,24,"Planed","Jalandhar","Amritsar",LocalDate.parse("2023-06-18"))
			));
	

	//Function for booking the ride
	@Override
	public List<String> bookRide(BookRideDTO bookRideDTO) {

		List<String> response = new ArrayList<String>();
		Booking booking = new Booking();
		RideSeeker rideSeeker = new RideSeeker();
		
		Optional<RideSeeker> rs = rideSeekerRepository.findById(bookRideDTO.getSeekerId());
		
		if(rs.isPresent())rideSeeker = rs.get();

		//If the user does not exist in the database then we can't book ride
		if (!rs.isPresent()) {
			
			response.add("User with this Id does not exists");
			response.add("fail");
			return response;
		}

		//when my required seats are 0 or less than 0
		else if (bookRideDTO.getRequiredNoOfSeats() <= 0) {
			response.add("No of seats should be more than 0");
			response.add("fail");
			
			return response;
		}

		else {
			//Ride can only book when ride is planed
			if (bookRideDTO.getRideStatus().equalsIgnoreCase("planed")) {
				
				//available seats should be more than the required seats
				if (bookRideDTO.getTotalNoOfSeats() - bookRideDTO.getFilledSeats() >= bookRideDTO
						.getRequiredNoOfSeats()) {
					int filledSeats = bookRideDTO.getFilledSeats() + bookRideDTO.getRequiredNoOfSeats();
					
					
					//updating seats in trip
					for(RideDTO rides : list) {
						if(rides.getTripId().equalsIgnoreCase(bookRideDTO.getTripId())) {
							rides.setFilledSeats(filledSeats);
						}
					}

					
					// setting the data in booking
					booking.setBookingId(bookRideDTO.getBookingId());
					booking.setRequiredNoOfSeats(bookRideDTO.getRequiredNoOfSeats());
					booking.setRideStatus(bookRideDTO.getRideStatus());
					booking.setSeekerId(bookRideDTO.getSeekerId());
					booking.setStatus("Booked");
					booking.setTripId(bookRideDTO.getTripId());

					// saving the data
					bookingRepository.save(booking);

					// returning the result
					response.add(booking.getBookingId());
					response.add("success");
					return response;

					// calling other modules API
					// getting object
					// returning required data
				} else {
					
					// when available seats are less than required seats
					
					response.add("Seats are not available");
					response.add("fail");
					return response;
				}
			} else {
				
				// when ride is already started
				response.add("Ride is already started");
				response.add("fail");
				return response;
			}
		}
	}

	
	//Function for canceling the ride
	@Override
	public List<String> cancelRide(BookRideDTO bookRideDTO) {

		List<String> response = new ArrayList<String>();
		Optional<Booking> booking = bookingRepository.findById(bookRideDTO.getBookingId());

		
		//Checking if there is a booking in the table for
		//respective bookingId
		if (booking.isPresent()) {
			Booking book = booking.get();
			
			//when the ride get started we cannot cancel that ride
			if (bookRideDTO.getRideStatus().equalsIgnoreCase("started")) {
				response.add("fail");
				response.add("Ride already started");
				
				return response;
			}

			// changing booking Status
			book.setStatus("Cancelled");
			
			//deleting the booking
			bookingRepository.deleteById(bookRideDTO.getBookingId());

			// setting filled seats
			//int filledSeats = bookRideDTO.getFilledSeats() - bookRideDTO.getRequiredNoOfSeats();
			
			
			//updating seats in trip
			for(RideDTO rides : list) {
				if(rides.getTripId().equalsIgnoreCase(bookRideDTO.getTripId())) {
					int filledSeats = rides.getFilledSeats() - bookRideDTO.getRequiredNoOfSeats();
					rides.setFilledSeats(filledSeats);
				}
			}

			response.add("success");
			response.add("Ride cancelled");
			return response;
		} else {
			
			response.add("fail");
			response.add("Booking does not exists");
			return response;
		}
	}

	
	//function for returning all the rides booked by a user
	@Override
	public List<BookRideDTO> bookedRides(String seekerId) {
		
		//getting all the rides booked by the user with given seekerId
		List<Booking> bookedRides = bookingRepository.findBySeekerId(seekerId);
		List<BookRideDTO> rides = new ArrayList<BookRideDTO>();
		
		
		//checking if there is some booking by the user
		if(!bookedRides.isEmpty()){
			
			//setting the data to the DTO
			for(Booking book : bookedRides) {
				
				BookRideDTO bookRide = new BookRideDTO();
				bookRide.setBookingId(book.getBookingId());
				bookRide.setRequiredNoOfSeats(book.getRequiredNoOfSeats());
				bookRide.setRideStatus(book.getRideStatus());
				bookRide.setSeekerId(book.getSeekerId());
				bookRide.setStatus(book.getStatus());
				bookRide.setTripId(book.getTripId());
				rides.add(bookRide);
			}
		}
		
		return rides;
		
	}
	
	
	
	//Function for returning all the trips
	@Override
	public List<RideDTO> getExistingRides() {
		
		return this.list;
	}

}
