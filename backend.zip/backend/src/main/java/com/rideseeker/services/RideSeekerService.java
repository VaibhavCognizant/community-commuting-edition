package com.rideseeker.services;

import java.util.List;

import com.rideseeker.customexception.IdNotPresent;
import com.rideseeker.models.RideSeekerDTO;

public interface RideSeekerService {
	public List<String> registerRideSeeker(RideSeekerDTO rideSeekerDTO);
	public String unRegisterRideSeekerOrUpdate(String seekerId,RideSeekerDTO rideSeekerDTO);
	public RideSeekerDTO getRideSeekerBasedOnId(String id) throws IdNotPresent;
}
