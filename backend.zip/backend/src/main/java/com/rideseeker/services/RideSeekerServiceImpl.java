package com.rideseeker.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import com.rideseeker.customexception.IdNotPresent;
import com.rideseeker.entities.RideSeeker;
import com.rideseeker.models.RideSeekerDTO;
import com.rideseeker.repository.BookingRepository;
import com.rideseeker.repository.RideSeekerRepository;
import com.rideseeker.repository.UserRepository;

import jakarta.transaction.Transactional;


@Service
public class RideSeekerServiceImpl implements RideSeekerService{

	public RideSeekerServiceImpl(RideSeekerRepository rideSeekerRepository, BookingRepository bookingRepository,UserRepository userRepository) {
		super();
		this.rideSeekerRepository = rideSeekerRepository;
		this.bookingRepository = bookingRepository;
		this.userRepository = userRepository;
	}


	private  RideSeekerRepository rideSeekerRepository;
	private  BookingRepository bookingRepository;
	private  UserRepository userRepository;
	
	// This method is for registering a new rideSeeker
	//Inputs to this methods are the details of the rideSeeker
	//Output of this method is the id generated and the status code
	@SuppressWarnings({"null"})
	@Override
	public List<String> registerRideSeeker(RideSeekerDTO rideSeekerDTO) {
		
		
		
		//list for storing the id and status
		List<String> result = new ArrayList<>();
		
		
		//Checking already existing adhar card
		if(rideSeekerRepository.findByAdharCard(Long.parseLong(rideSeekerDTO.getAdharCard())).isPresent()) {
			result.add("User with this adhar card already exists");
			result.add("fail");
			return result;
		}
		
		
		//i is for appending numbers to id  if id already present
		int i=1;
		
		
		//creating new rideSeeker object
		RideSeeker rideSeeker= new RideSeeker();
		
		rideSeeker.setAddress(rideSeekerDTO.getAddress());
		rideSeeker.setAdharCard(Long.parseLong(rideSeekerDTO.getAdharCard()));
		rideSeeker.setEmailId(rideSeekerDTO.getEmailId());
		rideSeeker.setFirstName(rideSeekerDTO.getFirstName());
		rideSeeker.setLastName(rideSeekerDTO.getLastName());
		rideSeeker.setPhone(Long.parseLong(rideSeekerDTO.getPhone()));
		
		//SETTING THE STATUS OF THE RIDESEEKER TO REGISTERED
		rideSeeker.setStatus("Registered");
		
		
		//CREATING OUR OWN ID
		String id = "RS"+rideSeekerDTO.getLastName().substring(0, 2).toUpperCase()
				+rideSeekerDTO.getYearOfBirth().substring(rideSeekerDTO.getYearOfBirth().length()-2, 
						rideSeekerDTO.getYearOfBirth().length());
		
		while(rideSeekerRepository.findById(id).isPresent()) {
			
			id = "RS"+rideSeekerDTO.getLastName().substring(0, 2).toUpperCase()
					+rideSeekerDTO.getYearOfBirth().substring(rideSeekerDTO.getYearOfBirth().length()-2, 
							rideSeekerDTO.getYearOfBirth().length())+i;
			i++;
		}
		
		rideSeeker.setRsId(id);
		
		//saving data
		RideSeeker rs = rideSeekerRepository.save(rideSeeker);

		if(rs != null) {
			result.add(id);
			result.add("success");
			return result;
		}
		else {
			result.add("Data not inserted");
			result.add("fail");
			
			return result;
		}
	}

	
	
	//This method is to upgrade or unregister a rideSeeker
	//Input to this method is the rideSeedker id and the new details
	//Output of this is the upgraded status
	@Override
	@Transactional
	public String unRegisterRideSeekerOrUpdate(String seekerId, RideSeekerDTO rideSeekerDTO) {
		
		Optional<RideSeeker> rideSeeker = rideSeekerRepository.findById(seekerId);
		String result="fail";
		
		if(rideSeeker.isPresent()) {
			RideSeeker rs = rideSeeker.get();
			
				
			rs.setStatus(rideSeekerDTO.getStatus());
			rs.setEmailId(rideSeekerDTO.getEmailId());
			rs.setFirstName(rideSeekerDTO.getFirstName());
			rs.setLastName(rideSeekerDTO.getLastName());
			rs.setPhone(Long.parseLong(rideSeekerDTO.getPhone()));
		
					
			//updating the data
			RideSeeker updatedRideSeeker = rideSeekerRepository.save(rs);
					
			//returning the changed status code
			if(updatedRideSeeker != null){
				result= "success";
			}
			else {
				result= "fail";
			}
			
			//deleting all the booked entry for that particular id in booking 
			//table if status is unregistered
			if(rs.getStatus().equals("Un-registered")) {
				bookingRepository.deleteBySeekerId(seekerId);
				rideSeekerRepository.deleteById(seekerId);
				userRepository.deleteById(seekerId);
			}
			
			
		}

		return result;
	}


	//used to get the data of a rideSeeker based on ID
	@Override
	public RideSeekerDTO getRideSeekerBasedOnId(String id) throws IdNotPresent{
		Optional<RideSeeker> rideSeeker = rideSeekerRepository.findById(id);
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		if(rideSeeker.isPresent()) {
			RideSeeker rs = rideSeeker.get();
			rideSeekerDTO.setAddress(rs.getAddress());
			rideSeekerDTO.setAdharCard(""+rs.getAdharCard());
			rideSeekerDTO.setEmailId(rs.getEmailId());
			rideSeekerDTO.setFirstName(rs.getFirstName());
			rideSeekerDTO.setLastName(rs.getLastName());
			rideSeekerDTO.setPhone(""+rs.getPhone());
			rideSeekerDTO.setRsId(rs.getRsId());
			rideSeekerDTO.setStatus(rs.getStatus());
			return rideSeekerDTO;
		}
		else {
			throw new IdNotPresent();
		}
	}



	
	
	

}
