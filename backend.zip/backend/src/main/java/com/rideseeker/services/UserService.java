package com.rideseeker.services;

import com.rideseeker.models.UserDTO;

public interface UserService {
	public UserDTO logIn(UserDTO userCredential);
	public UserDTO addNewUser(UserDTO user);
}
