package com.rideseeker.services;

import java.util.Optional;

import org.springframework.stereotype.Service;


import com.rideseeker.entities.Users;
import com.rideseeker.models.UserDTO;
import com.rideseeker.repository.UserRepository;


@Service
public class UserServiceImpl implements UserService{

	UserRepository userRepository;
	
	
	@Override
	public UserDTO logIn(UserDTO userCredential) {
		UserDTO userInfo = new UserDTO();
		Optional<Users> users = userRepository.findById(userCredential.getUserId());
//		System.out.println(users.get());
		if(users.isPresent()) {
			Users user = users.get();
			if(user.getPassword().equalsIgnoreCase(userCredential.getPassword())) {
				userInfo.setPassword(user.getPassword());
				userInfo.setRole(user.getRole());
				userInfo.setUserId(user.getUserId());;
			}
		}
		
		
		return userInfo;
	}

	@Override
	public UserDTO addNewUser(UserDTO user) {
		
		Users userInfo = new Users();
		
		userInfo.setPassword(user.getPassword());
		userInfo.setRole(user.getRole());
		userInfo.setUserId(user.getUserId());
		
		Users newUser = userRepository.save(userInfo);
		
		
		return user;
	}

	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

}
