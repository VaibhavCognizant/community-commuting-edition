

insert into rideseeker values('REPA01',987654321011,'pa@cognizant.com',9876543201,'Kairav','Pathania','Hyderabad','registered');
insert into rideseeker values('REPA02',987654000012,'ram@cognizant.com',9987654321,'Raghunath','Ganesh','Mumbai','registered');
insert into rideseeker values('REPA03',933354321013,'jag@cognizant.com',9987324321,'Dhruva','Jaganatha','Vizag','registered');
insert into rideseeker values('REPA04',988854321014,'radha@cognizant.com',9987654321,'Radha','Raman','Vellore','un-registered');

