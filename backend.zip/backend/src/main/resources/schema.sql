-- create database testdb;
-- use testdb;
create table rideSeeker(
	rsId varchar(30) primary key,
    adharCard long ,
    emailId varchar(30),
    phone long,
    firstName varchar(30),
    lastName varchar(30),
    address varchar(50),
    status varchar(30)
);
 
 