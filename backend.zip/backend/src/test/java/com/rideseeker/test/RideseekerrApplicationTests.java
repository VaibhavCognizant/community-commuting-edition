package com.rideseeker.test;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.rideseeker.rideseekerr.RideseekerrApplication;
@SpringBootTest(classes=RideseekerrApplication.class)

class RideseekerrApplicationTests {
	@Test
	void contextLoads() {
		
	}

}
