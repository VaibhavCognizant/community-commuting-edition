package com.rideseeker.test;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.any;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.rideseeker.entities.Booking;
import com.rideseeker.entities.RideSeeker;
import com.rideseeker.models.BookRideDTO;
import com.rideseeker.repository.BookingRepository;
import com.rideseeker.repository.RideSeekerRepository;
import com.rideseeker.rideseekerr.RideseekerrApplication;
import com.rideseeker.services.BookAndCancelRideServiceImpl;

@SpringBootTest(classes=RideseekerrApplication.class)
class TestBookAndCancelRideService {
    
	@InjectMocks
	private BookAndCancelRideServiceImpl bookAndCancelRide;
	
	@Mock
	private RideSeekerRepository rideSeekerRepository;
	
	@Mock
	private BookingRepository bookingRepository;

	@Test
	void bookRidePositive() {
	
		BookRideDTO bookRideDTO = new BookRideDTO();
		bookRideDTO.setFilledSeats(20);
		bookRideDTO.setRequiredNoOfSeats(5);
		bookRideDTO.setRideStatus("planed");
		bookRideDTO.setSeekerId("RERa98");
		bookRideDTO.setTotalNoOfSeats(40);
		bookRideDTO.setTripId("1234");
		
		
		
		Booking bookRide = new Booking();
		bookRide.setRequiredNoOfSeats(5);
		bookRide.setRideStatus("planed");
		bookRide.setSeekerId("RERa98");
		bookRide.setTripId("1234");
		
		RideSeeker rideSeeker = new RideSeeker();
		
		Optional<RideSeeker> rideSeekerOptional = Optional.of(rideSeeker);
		when(rideSeekerRepository.findById("RERa98")).thenReturn(rideSeekerOptional);
		
		bookingRepository.save(bookRide);
		List<String> response = bookAndCancelRide.bookRide(bookRideDTO);
		
		assertEquals("success",response.get(1));
	}
	
	@Test
	void bookRideNegative() {
		BookRideDTO bookRideDTO = new BookRideDTO();
		bookRideDTO.setFilledSeats(20);
		bookRideDTO.setRequiredNoOfSeats(0);
		bookRideDTO.setRideStatus("planed");
		bookRideDTO.setSeekerId("RERa98");
		bookRideDTO.setTotalNoOfSeats(40);
		bookRideDTO.setTripId("1234");
		
		when(rideSeekerRepository.findById("nsjn")).thenReturn(Optional.empty());
		List<String> response = bookAndCancelRide.bookRide(bookRideDTO);
		assertEquals("fail",response.get(1));
	}
	
	
	@Test
	void bookRideWhenRideStatusIsNotPlaned() {
		BookRideDTO bookRideDTO = new BookRideDTO();
		bookRideDTO.setFilledSeats(20);
		bookRideDTO.setRequiredNoOfSeats(5);
		bookRideDTO.setRideStatus("completed");
		bookRideDTO.setSeekerId("RERa98");
		bookRideDTO.setTotalNoOfSeats(40);
		bookRideDTO.setTripId("1234");
		
		RideSeeker rideSeeker = new RideSeeker();
		Optional<RideSeeker> rideSeekerOptional = Optional.of(rideSeeker);
		when(rideSeekerRepository.findById("RERa98")).thenReturn(rideSeekerOptional);
		
		List<String> response = bookAndCancelRide.bookRide(bookRideDTO);
		
		assertEquals("Ride is already started",response.get(0));
		assertEquals("fail",response.get(1));
	}
	
	@Test
	void bookRideWhenRequiredSeatsAreZeroOrLessThanZero() {
		
		BookRideDTO bookRideDTO = new BookRideDTO();
		bookRideDTO.setFilledSeats(20);
		bookRideDTO.setRequiredNoOfSeats(-5);
		bookRideDTO.setRideStatus("planed");
		bookRideDTO.setSeekerId("RERa98");
		bookRideDTO.setTotalNoOfSeats(22);
		bookRideDTO.setTripId("1234");
		
		RideSeeker rideSeeker = new RideSeeker();
		Optional<RideSeeker> rideSeekerOptional = Optional.of(rideSeeker);
		when(rideSeekerRepository.findById("RERa98")).thenReturn(rideSeekerOptional);
		List<String> response = bookAndCancelRide.bookRide(bookRideDTO);
		
		
		assertEquals("No of seats should be more than 0",response.get(0));
		assertEquals("fail",response.get(1));
	}
	
	
	
	
	
	@Test
	void bookRideWhenRequiredSeatsMoreThanAvailable() {
		BookRideDTO bookRideDTO = new BookRideDTO();
		bookRideDTO.setFilledSeats(20);
		bookRideDTO.setRequiredNoOfSeats(5);
		bookRideDTO.setRideStatus("planed");
		bookRideDTO.setSeekerId("RERa98");
		bookRideDTO.setTotalNoOfSeats(22);
		bookRideDTO.setTripId("1234");
		
		RideSeeker rideSeeker = new RideSeeker();
		Optional<RideSeeker> rideSeekerOptional = Optional.of(rideSeeker);
		when(rideSeekerRepository.findById("RERa98")).thenReturn(rideSeekerOptional);
		
		
		List<String> response = bookAndCancelRide.bookRide(bookRideDTO);
		
		assertEquals("Seats are not available",response.get(0));
		assertEquals("fail",response.get(1));
	}
	
	@Test
	void cancelRidePositive() {
		BookRideDTO bookRideDTO = new BookRideDTO();
		bookRideDTO.setFilledSeats(20);
		bookRideDTO.setRequiredNoOfSeats(5);
		bookRideDTO.setRideStatus("planed");
		bookRideDTO.setSeekerId("RERa98");
		bookRideDTO.setTotalNoOfSeats(22);
		bookRideDTO.setTripId("1234");
		bookRideDTO.setBookingId("RERa98");
		
		Booking booking = new Booking();
		booking.setBookingId("RERa98");
		booking.setRequiredNoOfSeats(0);
		
		when(bookingRepository.findById("RERa98")).thenReturn(Optional.of(booking));
		bookingRepository.save(booking);
		List<String> response = bookAndCancelRide.cancelRide(bookRideDTO);
		
		assertEquals("success",response.get(0));
	}
	
	
	@Test
	void cancelRideWhenRideAlreadyStarted() {
		BookRideDTO bookRideDTO = new BookRideDTO();
		bookRideDTO.setFilledSeats(20);
		bookRideDTO.setRequiredNoOfSeats(5);
		bookRideDTO.setRideStatus("started");
		bookRideDTO.setSeekerId("RERa98");
		bookRideDTO.setTotalNoOfSeats(22);
		bookRideDTO.setTripId("1234");
		bookRideDTO.setBookingId("RERa98");
		
		Booking booking = new Booking();
		booking.setBookingId("RERa98");
		booking.setRequiredNoOfSeats(0);
		
		when(bookingRepository.findById("RERa98")).thenReturn(Optional.of(booking));
		bookingRepository.save(booking);
		List<String> response = bookAndCancelRide.cancelRide(bookRideDTO);
		
		assertEquals("fail",response.get(0));
	}
	
	@Test
	void cancelRide() {
		BookRideDTO bookRideDTO = new BookRideDTO();
		bookRideDTO.setFilledSeats(20);
		bookRideDTO.setRequiredNoOfSeats(5);
		bookRideDTO.setRideStatus("started");
		bookRideDTO.setSeekerId("RERa98");
		bookRideDTO.setTotalNoOfSeats(22);
		bookRideDTO.setTripId("1234");
		
		
		List<String> response = bookAndCancelRide.cancelRide(bookRideDTO);
		
		assertEquals("fail",response.get(0));
		
	}
	
	@Test
	void getBookedRides() {

		
		List<Booking> booking = new ArrayList<>();
		Booking book = new Booking();
		booking.add(book);
		
		when(bookingRepository.findBySeekerId("RERA98")).thenReturn(booking);
		
		List<BookRideDTO> bookedRides = bookAndCancelRide.bookedRides("RERA98");
		
		assertTrue(true);
	}
	
	
	@Test
	void getBookedRidesNegative() {

		when(bookingRepository.findBySeekerId("RERA98")).thenReturn(Collections.emptyList());
		
		List<BookRideDTO> bookedRides = bookAndCancelRide.bookedRides("RERA98");
		
		assertTrue(bookedRides.isEmpty());
		
	}

}
