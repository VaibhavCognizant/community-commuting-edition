package com.rideseeker.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import com.rideseeker.controllers.RideSeekerController;
import com.rideseeker.models.BookRideDTO;
import com.rideseeker.models.RideSeekerDTO;
import com.rideseeker.rideseekerr.RideseekerrApplication;
import com.rideseeker.services.BookAndCancelRideServiceImpl;
import com.rideseeker.services.RideSeekerServiceImpl;



@SpringBootTest(classes=RideseekerrApplication.class)
class TestController {

	
	
	@Mock
	private RideSeekerServiceImpl rideSeeker;
	@Mock
	private BookAndCancelRideServiceImpl bookAndCancelRide;
	@InjectMocks
	private RideSeekerController rideSeekerController;
	@Autowired
	private LocalValidatorFactoryBean validator;

	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	
	@Test
	void testRegisterRideSeekerPositive() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
		rideSeekerDTO.setFirstName("Ram");
		rideSeekerDTO.setLastName("Pothani");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		List <String> response = new ArrayList<String>();
		response.add("RSPO98");
		response.add("success");
		when(rideSeeker.registerRideSeeker(rideSeekerDTO)).thenReturn(response);
		
		ResponseEntity<?> responseEntity = rideSeekerController.registerRideSeeker(rideSeekerDTO);
		assertEquals(201,responseEntity.getStatusCodeValue());
	}
	
	
	@Test 
	void testRegisterSeekerNegative() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		List <String> response = new ArrayList<String>();
		response.add("Data not inserted");
		response.add("fail");
		when(rideSeeker.registerRideSeeker(rideSeekerDTO)).thenReturn(response);
		
		ResponseEntity<?> responseEntity = rideSeekerController.registerRideSeeker(rideSeekerDTO);
		assertEquals(400,responseEntity.getStatusCodeValue());
	}
	
	
	
	//----------------------------------------VALIDATING FIRST NAME--------------------------------------------------
	
	@Test
	void testRegisterSeekerWhenFirstNameIsInvalid() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
		rideSeekerDTO.setFirstName("");
		rideSeekerDTO.setLastName("Pothani");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		
		validator.validateProperty(rideSeekerDTO, "firstName")
		.stream()
		.forEach((constraintViolation)->assertNotNull(constraintViolation));
	}
	
	@Test
	void testRegisterSeekerWhenFirstNameIsInvalidAndCheckingMessage() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
//		rideSeekerDTO.setFirstName("");
		rideSeekerDTO.setLastName("Pothani");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		
		validator.validateProperty(rideSeekerDTO, "firstName")
		.stream()
		.forEach((constraintViolation)->assertEquals("First name is required",constraintViolation.getMessage()));
	}
	
	@Test 
	void testRegisterSeekerWhenFirstNameIsValid() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
		rideSeekerDTO.setFirstName("Ram");
		rideSeekerDTO.setLastName("Pothani");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		
		validator.validateProperty(rideSeekerDTO, "firstName")
		.stream()
		.forEach((constraintViolation)->assertNull(constraintViolation));
	}
	
	
	//----------------------------------------VALIDATING LAST NAME--------------------------------------------------
	@Test
	void testRegisterSeekerWhenLastNameIsInvalid() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
		rideSeekerDTO.setFirstName("Ram");
		rideSeekerDTO.setLastName("");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		
		validator.validateProperty(rideSeekerDTO, "lastName")
		.stream()
		.forEach((constraintViolation)->assertNotNull(constraintViolation));
	}

	
	@Test
	void testRegisterSeekerWhenLastNameIsValid() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
		rideSeekerDTO.setFirstName("Ram");
		rideSeekerDTO.setLastName("Pothani");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		
		validator.validateProperty(rideSeekerDTO, "lastName")
		.stream()
		.forEach((constraintViolation)->assertNull(constraintViolation));
	}
	
	@Test
	void testRegisterSeekerWhenLastNameIsInvalidAndCheckingMessage() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
		rideSeekerDTO.setFirstName("Ram");
//		rideSeekerDTO.setLastName("Pothani");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		
		validator.validateProperty(rideSeekerDTO, "lastName")
		.stream()
		.forEach((constraintViolation)->assertEquals("Last name is required",constraintViolation.getMessage()));
	}
	
	
	
	//--------------------------------Testing update api----------------------------------------------------
	@Test
	void testUpdateRideSeekerPositive() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
		rideSeekerDTO.setFirstName("Ram");
		rideSeekerDTO.setLastName("Pothani");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		rideSeekerDTO.setStatus("Un-registered");
		when(rideSeeker.unRegisterRideSeekerOrUpdate("RAPO98", rideSeekerDTO)).thenReturn("success");
		
		ResponseEntity<?> responseEntity = rideSeekerController.unregisterOrUpdateRideSeeker("RAPO98", rideSeekerDTO);
		assertEquals(200,responseEntity.getStatusCodeValue());
	}
	
	@Test
	void testUpdateRideSeekerNegative() {
		RideSeekerDTO rideSeekerDTO = new RideSeekerDTO();
		rideSeekerDTO.setAddress("Jalandhar");
		rideSeekerDTO.setAdharCard("123456789012");
		rideSeekerDTO.setEmailId("ram@cognizant.com");
		rideSeekerDTO.setFirstName("Ram");
		rideSeekerDTO.setLastName("Pothani");
		rideSeekerDTO.setPhone("9876543210");
		rideSeekerDTO.setYearOfBirth("1998");
		rideSeekerDTO.setStatus("Un-registered");
		when(rideSeeker.unRegisterRideSeekerOrUpdate("RAPO9", rideSeekerDTO)).thenReturn("fail");
		
		ResponseEntity<?> responseEntity = rideSeekerController.unregisterOrUpdateRideSeeker("RAPO9", rideSeekerDTO);
		assertEquals(400,responseEntity.getStatusCodeValue());
	}
	

	//----------------------------------------TESTING BOOK RIDE API--------------------------------------------------
	
	@Test
	void testBookRidePositive() {
		BookRideDTO bookRide = new BookRideDTO();
		bookRide.setBookingId("BOOK01");
		bookRide.setFilledSeats(20);
		bookRide.setRequiredNoOfSeats(5);
		bookRide.setRideStatus("Planed");
		bookRide.setSeekerId("RSPO98");
		bookRide.setTotalNoOfSeats(30);
		
		List<String> response = new ArrayList<String>();
		response.add("TRIP01");
		response.add("success");
		
		when(bookAndCancelRide.bookRide(bookRide)).thenReturn(response);
		
		ResponseEntity<?> responseEntity = rideSeekerController.bookRide(bookRide);
		assertEquals(201,responseEntity.getStatusCodeValue());
		
		
	}
	
	@Test
	void testBookRideNegative() {
		BookRideDTO bookRide = new BookRideDTO();
		bookRide.setBookingId("BOOK01");
		bookRide.setFilledSeats(20);
		bookRide.setRequiredNoOfSeats(5);
		bookRide.setRideStatus("Started");
		bookRide.setSeekerId("RSPO98");
		bookRide.setTotalNoOfSeats(30);
		
		List<String> response = new ArrayList<String>();
		response.add("Ride is already planned");
		response.add("fail");
		
		when(bookAndCancelRide.bookRide(bookRide)).thenReturn(response);
		
		ResponseEntity<?> responseEntity = rideSeekerController.bookRide(bookRide);
		assertEquals(400,responseEntity.getStatusCodeValue());
		
		
	}
	
	

//-----------------------------TESTING UPDATE RIDE API-----------------------------------
	@Test
	void cancelRidePositive() {
		BookRideDTO cancelRide = new BookRideDTO();
		cancelRide.setBookingId("BOOK01");
		cancelRide.setFilledSeats(20);
		cancelRide.setRequiredNoOfSeats(5);
		cancelRide.setRideStatus("Planed");
		cancelRide.setSeekerId("RSPO98");
		cancelRide.setTotalNoOfSeats(30);
		
		List<String> response = new ArrayList<String>();
		response.add("success");
		response.add("Ride cancelled");
		
		when(bookAndCancelRide.cancelRide(cancelRide)).thenReturn(response);
		ResponseEntity<?> responseEntity = rideSeekerController.cancelRide(cancelRide);
		assertEquals(200,responseEntity.getStatusCodeValue());
	}
	
	@Test
	void cancelRideNegative() {
		BookRideDTO cancelRide = new BookRideDTO();
		cancelRide.setBookingId("BOOK01");
		cancelRide.setFilledSeats(20);
		cancelRide.setRequiredNoOfSeats(5);
		cancelRide.setRideStatus("started");
		cancelRide.setSeekerId("RSPO98");
		cancelRide.setTotalNoOfSeats(30);
		
		List<String> response = new ArrayList<String>();
		response.add("fail");
		response.add("Ride already started");
		
		when(bookAndCancelRide.cancelRide(cancelRide)).thenReturn(response);
		ResponseEntity<?> responseEntity = rideSeekerController.cancelRide(cancelRide);
		assertEquals(400,responseEntity.getStatusCodeValue());
	}
}
