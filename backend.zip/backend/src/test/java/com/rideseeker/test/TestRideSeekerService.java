package com.rideseeker.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.rideseeker.customexception.IdNotPresent;
import com.rideseeker.entities.RideSeeker;
import com.rideseeker.models.RideSeekerDTO;
import com.rideseeker.repository.BookingRepository;
import com.rideseeker.repository.RideSeekerRepository;
import com.rideseeker.repository.UserRepository;
import com.rideseeker.rideseekerr.RideseekerrApplication;
import com.rideseeker.services.RideSeekerServiceImpl;

@SpringBootTest(classes=RideseekerrApplication.class)
class TestRideSeekerService {

	@Mock
	private RideSeekerRepository rideSeekerRepository;
	
	@Mock
	private BookingRepository bookingRepository;
	
	@Mock
	private UserRepository userRepository;
	
	@InjectMocks
	RideSeekerServiceImpl rideSeekerServiceImpl;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	
	@Test
	void rideSeekerRegisterPositive() {
		try {
			RideSeeker mockOfRideSeeker=Mockito.mock(RideSeeker.class);
			RideSeekerDTO rideSeekerDTO =new RideSeekerDTO();
			rideSeekerDTO.setAddress("Phagwara");
			rideSeekerDTO.setAdharCard("123456789012");
			rideSeekerDTO.setEmailId("ram@cognizant.com");
			rideSeekerDTO.setFirstName("Ram");
			rideSeekerDTO.setLastName("Rajan");
			rideSeekerDTO.setPhone("987654345");
			rideSeekerDTO.setYearOfBirth("1998");
			when(rideSeekerRepository.save(Mockito.any())).thenReturn(mockOfRideSeeker);
			
			List<String> actual = rideSeekerServiceImpl.registerRideSeeker(rideSeekerDTO);
			assertEquals("RSRA98",actual.get(0));
			assertEquals("success",actual.get(1));
		}catch(Exception e) {
			
			assertTrue(false);
		}
	}

	
	@Test
	void rideSeekerRegisterWhenAdharCardAlreadyExists() {
		try {
			RideSeeker mockOfRideSeeker=new RideSeeker();
			Optional<RideSeeker> optionalOfRideSeeker = Optional.of(mockOfRideSeeker);
			
			RideSeekerDTO rideSeekerDTO =new RideSeekerDTO();
			rideSeekerDTO.setAddress("Phagwara");
			rideSeekerDTO.setAdharCard("123456789012");
			rideSeekerDTO.setEmailId("ram@cognizant.com");
			rideSeekerDTO.setFirstName("Ram");
			rideSeekerDTO.setLastName("Rajan");
			rideSeekerDTO.setPhone("987654345");
			rideSeekerDTO.setYearOfBirth("1998");
			
			when(rideSeekerRepository.findByAdharCard(Long.parseLong(rideSeekerDTO.getAdharCard()))).thenReturn(optionalOfRideSeeker);
			
			List<String> actual = rideSeekerServiceImpl.registerRideSeeker(rideSeekerDTO);
			assertEquals("User with this adhar card already exists",actual.get(0));
			assertEquals("fail",actual.get(1));
		}catch(Exception e) {
			
			assertTrue(false);
		}
	}
	
	@Test
	void rideSeekerRegisterWhenIdAlreadyExists() {
		try {
			
			RideSeeker rideSeeker=new RideSeeker();
			rideSeeker.setAddress("Phagwara");
			rideSeeker.setAdharCard(123456789012L);
			rideSeeker.setEmailId("ram@cognizant.com");
			rideSeeker.setFirstName("Ram");
			rideSeeker.setLastName("Rajan");
			rideSeeker.setPhone(9876543453L);
		
			
			
			Optional<RideSeeker> optionalOfRideSeeker = Optional.of(rideSeeker);
			
			RideSeekerDTO rideSeekerDTO =new RideSeekerDTO();
			rideSeekerDTO.setAddress("Phagwara");
			rideSeekerDTO.setAdharCard("123456789012");
			rideSeekerDTO.setEmailId("ram@cognizant.com");
			rideSeekerDTO.setFirstName("Ram");
			rideSeekerDTO.setLastName("Rajan");
			rideSeekerDTO.setPhone("987654345");
			rideSeekerDTO.setYearOfBirth("1998");
			
			when(rideSeekerRepository.findById("RSRA98")).thenReturn(optionalOfRideSeeker);
			
			when(rideSeekerRepository.save(Mockito.any())).thenReturn(rideSeeker);
			List<String> actual = rideSeekerServiceImpl.registerRideSeeker(rideSeekerDTO);
			
			//assertEquals("RSRA981",actual.get(0));
			assertEquals("success",actual.get(1));
		}catch(Exception e) {
			
			assertTrue(false);
		}
	}
	
	 @Test
	 void rideSeekerRegisterNegative() {
		try {
			RideSeeker mockOfRideSeeker=Mockito.mock(RideSeeker.class);
			RideSeekerDTO rideSeekerDTO =new RideSeekerDTO();
			rideSeekerDTO.setAddress("Phagwara");
			rideSeekerDTO.setAdharCard("123456789012");
			rideSeekerDTO.setEmailId("ram@cognizant.com");
			rideSeekerDTO.setFirstName("Ram");
			rideSeekerDTO.setLastName("Rajan");
			rideSeekerDTO.setPhone("9876543451");
			rideSeekerDTO.setYearOfBirth("1998");

			when(rideSeekerRepository.save(Mockito.any())).thenReturn(null);
			
			List<String> actual = rideSeekerServiceImpl.registerRideSeeker(rideSeekerDTO);
			
			assertEquals("fail",actual.get(1));

		}catch(Exception e) {
			
			assertTrue(false);
		}
	 }
	 
	 @Test
	 void rideSeekerUnRegistered(){
		 try {
				RideSeeker rideSeeker=new RideSeeker();
				rideSeeker.setAddress("Phagwara");
				rideSeeker.setAdharCard(123456789012L);
				rideSeeker.setEmailId("ram@cognizant.com");
				rideSeeker.setFirstName("Ram");
				rideSeeker.setLastName("Rajan");
				rideSeeker.setPhone(9876543453L);
				rideSeeker.setStatus("Un-registered");
				
				RideSeekerDTO rideSeekerDTO =new RideSeekerDTO();
				rideSeekerDTO.setAddress("Phagwara");
				rideSeekerDTO.setAdharCard("123456789012");
				rideSeekerDTO.setEmailId("ram@cognizant.com");
				rideSeekerDTO.setFirstName("Ram");
				rideSeekerDTO.setLastName("Rajan");
				rideSeekerDTO.setPhone("9876543453");
				rideSeekerDTO.setYearOfBirth("1998");
				rideSeekerDTO.setStatus("Un-registered");
				Mockito.when(rideSeekerRepository.findById("RSRA98")).thenReturn(Optional.of(rideSeeker));
				bookingRepository.deleteBySeekerId("RSRA98");
				userRepository.deleteById("RSRA98");
				Mockito.when(rideSeekerRepository.save(Mockito.any(RideSeeker.class))).thenReturn(rideSeeker);
				
				
				
				String res =  rideSeekerServiceImpl.unRegisterRideSeekerOrUpdate("RSRA98", rideSeekerDTO);

				assertEquals("success",res);
				
			}catch(Exception e) {
				
				assertTrue(false);
			}
	 }
	 @Test
	 void rideSeekerUnRegisteredNegative(){
		 try {
				RideSeeker mockOfRideSeeker=Mockito.mock(RideSeeker.class);
				RideSeekerDTO rideSeekerDTO =new RideSeekerDTO();
				rideSeekerDTO.setAddress("Phagwara");
				rideSeekerDTO.setAdharCard("123456789012");
				rideSeekerDTO.setEmailId("ram@cognizant.com");
				rideSeekerDTO.setFirstName("Ram");
				rideSeekerDTO.setLastName("Rajan");
				rideSeekerDTO.setPhone("9876543452");
				rideSeekerDTO.setYearOfBirth("1998");
				Mockito.when(rideSeekerRepository.findById("RSRA98")).thenReturn(Optional.of(mockOfRideSeeker));
				Mockito.when(rideSeekerRepository.save(Mockito.any(RideSeeker.class))).thenReturn(mockOfRideSeeker);
				
				
				String res =  rideSeekerServiceImpl.unRegisterRideSeekerOrUpdate("RSA9", rideSeekerDTO);
				
				assertEquals("fail",res);
				
			}catch(Exception e) {
				e.printStackTrace();
				assertTrue(false);
			}
	 }
	 
	 @Test
	 void rideSeekerWhenUpdateDoesNotStoreTheData(){
		 try {
				RideSeeker rideSeeker=new RideSeeker();
				rideSeeker.setAddress("Phagwara");
				rideSeeker.setAdharCard(123456789012L);
				rideSeeker.setEmailId("ram@cognizant.com");
				rideSeeker.setFirstName("Ram");
				rideSeeker.setLastName("Rajan");
				rideSeeker.setPhone(9876543453L);
				rideSeeker.setStatus("Un-registered");
				
				RideSeekerDTO rideSeekerDTO =new RideSeekerDTO();
				rideSeekerDTO.setAddress("Phagwara");
				rideSeekerDTO.setAdharCard("123456789012");
				rideSeekerDTO.setEmailId("ram@cognizant.com");
				rideSeekerDTO.setFirstName("Ram");
				rideSeekerDTO.setLastName("Rajan");
				rideSeekerDTO.setPhone("9876543453");
				rideSeekerDTO.setYearOfBirth("1998");
				rideSeekerDTO.setStatus("Un-registered");
				Mockito.when(rideSeekerRepository.findById("RSRA98")).thenReturn(Optional.of(rideSeeker));
				bookingRepository.deleteBySeekerId("RSRA98");
				userRepository.deleteById("RSRA98");
				Mockito.when(rideSeekerRepository.save(Mockito.any(RideSeeker.class))).thenReturn(null);
				
				
				
				String res =  rideSeekerServiceImpl.unRegisterRideSeekerOrUpdate("RSRA98", rideSeekerDTO);

				assertEquals("fail",res);
				
			}catch(Exception e) {
				
				assertTrue(false);
			}
	 }
	 
	 
	 @Test
	 void getDataBasedOnTheId() {
		 
		 RideSeeker rideSeeker = new RideSeeker();
		 when(rideSeekerRepository.findById("RSRA98")).thenReturn(Optional.of(rideSeeker));
		 
		 try {
			RideSeekerDTO result = rideSeekerServiceImpl.getRideSeekerBasedOnId("RSRA98");
			
			assertTrue(true);
		} catch (IdNotPresent e) {
			assertTrue(false);
			e.printStackTrace();
		}
	 }
	 
	 @Test
	 void getDataBasedOnTheIdWhenIdIsNotThere() {
		 RideSeeker rideSeeker = Mockito.mock(RideSeeker.class);;
		 when(rideSeekerRepository.findById("RSRA98")).thenReturn(Optional.empty());
		 
		 try {
			RideSeekerDTO result = rideSeekerServiceImpl.getRideSeekerBasedOnId("RSRA98");
			
			assertTrue(false);
		} catch (IdNotPresent e) {
			assertTrue(true);
			e.printStackTrace();
		}
	 }
	 
}
