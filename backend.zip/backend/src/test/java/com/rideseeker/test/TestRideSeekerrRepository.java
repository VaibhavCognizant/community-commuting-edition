package com.rideseeker.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.rideseeker.entities.RideSeeker;
import com.rideseeker.repository.RideSeekerRepository;
import com.rideseeker.rideseekerr.RideseekerrApplication;

@DataJpaTest
@ContextConfiguration(classes = RideseekerrApplication.class)
public class TestRideSeekerrRepository {

	@Autowired
	private RideSeekerRepository rideSeekerRepository;
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void testFindByIdPositive(){
		RideSeeker rideSeeker = new RideSeeker();
		rideSeeker.setRsId("REPA1999");
		rideSeeker.setAdharCard(123456789012l);
		rideSeeker.setEmailId("ram@cognizant.com");
		rideSeeker.setAddress("Hyderabad");
		rideSeeker.setFirstName("Ram");
		rideSeeker.setLastName("Rajan");
		rideSeeker.setStatus("abc");
		entityManager.persist(rideSeeker);
		Optional<RideSeeker> seeker=rideSeekerRepository.findById("REPA1999");
		assertTrue(seeker.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<RideSeeker> rideSeeker=rideSeekerRepository.findById("REPA1999");
		assertTrue(!rideSeeker.isPresent());
	}
	
	@Test
	public void testFindAllPositive(){
		RideSeeker rideSeeker = new RideSeeker();
		rideSeeker.setRsId("REPA1999");
		rideSeeker.setAdharCard(123456789012l);
		rideSeeker.setEmailId("ram@cognizant.com");
		rideSeeker.setAddress("Hyderabad");
		rideSeeker.setFirstName("Ram");
		rideSeeker.setLastName("Rajan");
		rideSeeker.setStatus("Registered");
		entityManager.persist(rideSeeker);
		Iterable<RideSeeker> it=rideSeekerRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testFindAllNegative() {
		Iterable<RideSeeker> it = rideSeekerRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testSavePositive(){
		RideSeeker rideSeeker = new RideSeeker();
		rideSeeker.setRsId("REPA1999");
		rideSeeker.setAdharCard(123456789012l);
		rideSeeker.setEmailId("ram@cognizant.com");
		rideSeeker.setAddress("Hyderabad");
		rideSeeker.setFirstName("Ram");
		rideSeeker.setLastName("Rajan");
		rideSeeker.setStatus("registered");

		rideSeekerRepository.save(rideSeeker);


		Optional<RideSeeker> seeker=rideSeekerRepository.findById("REPA1999");
		assertTrue(seeker.isPresent());
	}
	
	@Test
	public void testDeletePositive(){
		RideSeeker rideSeeker = new RideSeeker();
		rideSeeker.setRsId("REPA1999");
		rideSeeker.setAdharCard(123456789012l);
		rideSeeker.setEmailId("ram@cognizant.com");
		rideSeeker.setAddress("Hyderabad");
		rideSeeker.setFirstName("Ram");
		rideSeeker.setLastName("Rajan");
		rideSeeker.setStatus("registered");
		entityManager.persist(rideSeeker);
		rideSeekerRepository.delete(rideSeeker);
		Optional<RideSeeker> seeker=rideSeekerRepository.findById("REPA1999");
		assertTrue(!seeker.isPresent());
	}
}
